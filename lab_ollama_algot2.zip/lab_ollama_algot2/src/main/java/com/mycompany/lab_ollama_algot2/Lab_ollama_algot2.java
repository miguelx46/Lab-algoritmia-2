/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.lab_ollama_algot2;

/**
 *
 * @author migue
 */
public class Lab_ollama_algot2 {

    public static void main(String[] args) {
        GUI frame = new GUI();
        frame.setVisible(true);
        frame.setSize(680, 700);
    }
}
